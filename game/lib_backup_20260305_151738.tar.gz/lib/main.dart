import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:mg_common_game/systems/systems.dart';
import 'package:mg_common_game/systems/gacha/gacha_pool.dart';
import 'package:mg_common_game/systems/battlepass/battlepass_config.dart';
import 'package:mg_common_game/systems/battlepass/battlepass_manager.dart';
import 'package:mg_common_game/systems/quests/daily_quest.dart';
import 'package:get_it/get_it.dart';
import 'package:mg_common_game/systems/progression/achievement_manager.dart';
import 'package:mg_common_game/systems/gacha/gacha_manager.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flame/game.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'core/models/game_state.dart';
import 'game/cat_alchemy_game.dart';
import 'providers/game_providers.dart';
import 'ui/hud/mg_idle_hud.dart';
import 'package:mg_common_game/systems/progression/prestige_manager.dart';
import 'screens/daily_quest_screen.dart';
import 'screens/battlepass_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive for data persistence
  await Hive.initFlutter();

  // Register Hive adapters
  Hive.registerAdapter(GameStateAdapter());

  // Open game state box
  await Hive.openBox<GameState>('gameState');

  // DailyQuest 시스템
  GetIt.I.registerSingleton(DailyQuestManager());
  // BattlePass 시스템
  GetIt.I.registerSingleton(BattlePassManager());
  // Collection 시스템
  if (!GetIt.I.isRegistered<CollectionManager>()) {
    GetIt.I.registerSingleton(CollectionManager());
    _registerCollections();
  }
  _setupBattlePass();
  _registerDailyQuests();
  runApp(
    const ProviderScope(
      child: CatAlchemyApp(),
    ),
  );
}

class CatAlchemyApp extends StatelessWidget {
  const CatAlchemyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '고양이 연금술 공방',
      theme: ThemeData(
        primarySwatch: Colors.brown,
        scaffoldBackgroundColor: const Color(0xFFF5E6D3), // Warm cream
        fontFamily: 'Pretendard', // TODO: Add font to pubspec
      ),
      routes: {
        '/daily-quest': (_) => const DailyQuestScreen(),
        '/battlepass': (_) => const BattlePassScreen(),
      },
      home: const GameScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

/// Main game screen with Flame game widget
class GameScreen extends ConsumerStatefulWidget {
  const GameScreen({super.key});

  @override
  ConsumerState<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends ConsumerState<GameScreen> {
  late CatAlchemyGame _game;

  @override
  void initState() {
    super.initState();
    _game = CatAlchemyGame(ref);
  }

  @override
  Widget build(BuildContext context) {
    final gameState = ref.watch(gameStateProvider);

    return Scaffold(
      body: GameWidget<CatAlchemyGame>(
        game: _game,
        overlayBuilderMap: {
          'HUD': (BuildContext context, CatAlchemyGame game) {
            return MGIdleHud(
              gold: gameState.gold,
              gems: gameState.gems,
              workshopLevel: gameState.workshopLevel,
              onSettings: () => game.navigateTo('settings'),
              onTutorial: () => game.navigateTo('tutorial'),
              onCollection: () => game.navigateTo('collection'),
              onPrestige: () => game.navigateTo('prestige'),
              onEvents: () => game.navigateTo('events'),
            );
          },
        },
        initialActiveOverlays: const ['HUD'],
      ),
    );
  }
}


void _setupGacha() {
  final gacha = GetIt.I<GachaManager>();
  
  gacha.registerPool(GachaPool(
    id: 'standard_pool',
    name: '스탠다드 뽑기',
    items: [
      // N (50%)
      ...List.generate(20, (i) => GachaItem(
        id: 'n_item_$i',
        rarity: Rarity.N,
        weight: 2.5,
      )),
      
      // R (35%)
      ...List.generate(10, (i) => GachaItem(
        id: 'r_item_$i',
        rarity: Rarity.R,
        weight: 3.5,
      )),
      
      // SR (12%)
      ...List.generate(5, (i) => GachaItem(
        id: 'sr_item_$i',
        rarity: Rarity.SR,
        weight: 2.4,
      )),
      
      // SSR (2.7%)
      GachaItem(id: 'ssr_item_1', rarity: Rarity.SSR, weight: 2.7),
      
      // UR (0.3%)
      GachaItem(id: 'ur_item_1', rarity: Rarity.UR, weight: 0.3),
    ],
    pityThreshold: 80,
    softPityStart: 70,
  ));

  // Prestige 시스템 (mg_common_game)
  if (!GetIt.I.isRegistered<PrestigeManager>()) {
    final prestigeManager = PrestigeManager();
    GetIt.I.registerSingleton(prestigeManager);
    _setupPrestige(prestigeManager);
  }
}


void _registerAchievements() {
  final achievement = GetIt.I<AchievementManager>();
  
  achievement.registerAchievement(Achievement(
    id: 'gold_1000',
    title: '골드 1000 달성',
    description: '총 골드 1000을 모으세요',
    iconAsset: 'assets/achievements/gold_1000.png',
  ));
  
  achievement.registerAchievement(Achievement(
    id: 'level_10',
    title: '레벨 10 달성',
    description: '레벨 10에 도달하세요',
    iconAsset: 'assets/achievements/level_10.png',
  ));
  
  achievement.registerAchievement(Achievement(
    id: 'play_100',
    title: '100판 플레이',
    description: '게임을 100판 플레이하세요',
    iconAsset: 'assets/achievements/play_100.png',
  ));
}


void _registerDailyQuests() {
  final dailyQuest = GetIt.I<DailyQuestManager>();
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'collect_gold',
    title: '골드 모으기',
    description: '골드 1000 획득',
    targetValue: 1000,
    goldReward: 500,
    xpReward: 10,
  ));
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'play_games',
    title: '게임 플레이',
    description: '게임 5판 플레이',
    targetValue: 5,
    goldReward: 300,
    xpReward: 5,
  ));
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'level_up',
    title: '레벨업',
    description: '레벨 1 상승',
    targetValue: 1,
    goldReward: 200,
    xpReward: 3,
  ));
}


void _setupBattlePass() {
  final bp = GetIt.I<BattlePassManager>();

  final season = BPSeasonBuilder.create28DaySeason(
    id: 'season_1',
    nameKr: '시즌 1',
    startDate: DateTime.now().subtract(const Duration(days: 1)),
    maxLevel: 50,
    expPerLevel: 1000,
  );

  bp.setSeason(season);
  bp.setMissions(
    daily: BPSeasonBuilder.createDefaultDailyMissions(),
    weekly: BPSeasonBuilder.createDefaultWeeklyMissions(),
  );
}

void _setupPrestige(PrestigeManager manager) {
  // ── Prestige Upgrades (idle game defaults) ──────────────────
  // Milestone targets: 5→Gold, 10→XP, 25→Speed (unlocked via prestige points)
  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'gold_multiplier',
    name: '골드 배수',
    description: '골드 획득량 +10%',
    maxLevel: 50,
    costPerLevel: 1,
    bonusPerLevel: 0.1,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'xp_boost',
    name: 'XP 부스트',
    description: 'XP 획득량 +15%',
    maxLevel: 40,
    costPerLevel: 2,
    bonusPerLevel: 0.15,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'production_speed',
    name: '생산 속도',
    description: '생산 속도 +20%',
    maxLevel: 30,
    costPerLevel: 2,
    bonusPerLevel: 0.2,
  ));

  // ── Prestige Callbacks ──────────────────────────────────────
  manager.onPrestigePerformed = (level, points) {
    debugPrint('Prestige level $level reached (+$points points)');
  };

  // TODO: Add game-specific reset callbacks:
  // manager.registerResetCallback(() {
  //   GetIt.I<ProgressionManager>().reset();
  //   GetIt.I<GoldManager>().reset();
  // });
}

void _registerCollections() {
  final collection = GetIt.I<CollectionManager>();

  // Characters 컬렉션
  collection.registerCollection(const Collection(
    id: 'characters',
    name: '캐릭터',
    description: '모든 캐릭터를 수집하세요',
    items: [
      CollectionItem(
        id: 'char_warrior',
        name: '전사',
        description: '강인한 근접 전투 캐릭터',
        rarity: CollectionRarity.common,
      ),
      CollectionItem(
        id: 'char_mage',
        name: '마법사',
        description: '강력한 마법 공격 캐릭터',
        rarity: CollectionRarity.rare,
      ),
      CollectionItem(
        id: 'char_archer',
        name: '궁수',
        description: '원거리 정밀 공격 캐릭터',
        rarity: CollectionRarity.rare,
      ),
      CollectionItem(
        id: 'char_assassin',
        name: '암살자',
        description: '치명적인 은신 공격 캐릭터',
        rarity: CollectionRarity.epic,
      ),
      CollectionItem(
        id: 'char_healer',
        name: '힐러',
        description: '팀을 치유하는 지원 캐릭터',
        rarity: CollectionRarity.legendary,
      ),
    ],
    completionReward: CollectionReward(gold: 10000, gems: 500, experience: 2000),
    milestoneRewards: {
      25: CollectionReward(gold: 1000, gems: 50),
      50: CollectionReward(gold: 3000, gems: 150),
      75: CollectionReward(gold: 5000, gems: 300),
    },
  ));

  // 아이템 해제 콜백 (햅틱 피드백)
  collection.onItemUnlocked = (collectionId, itemId) {
    // SettingsManager가 등록되어 있으면 햅틱 피드백
    debugPrint('Collection item unlocked: $collectionId / $itemId');
  };
}
